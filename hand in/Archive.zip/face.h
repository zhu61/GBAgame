#ifndef FACE_BITMAP_H
#define FACE_BITMAP_H
extern const unsigned short face[400];
#define FACE_WIDTH 20
#define FACE_HEIGHT 20
#endif