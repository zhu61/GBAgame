#ifndef WIN_BITMAP_H
#define WIN_BITMAP_H
extern const unsigned short win[38400];
#define WIN_WIDTH 240
#define WIN_HEIGHT 160
#endif