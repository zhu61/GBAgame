#ifndef MONSTER_BITMAP_H
#define MONSTER_BITMAP_H
extern const unsigned short monster[400];
#define MONSTER_WIDTH 20
#define MONSTER_HEIGHT 20
#endif