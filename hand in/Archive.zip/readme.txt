This is a game that is simlar to dodge ball.
There is a devil face floating around you have to avoid while playing the game.
In order to win, you have to get your face to the top of the window.
To play:
use up,left, right button. But in this game, you cannot go back.
For the reset game, use down button.
Have fun!